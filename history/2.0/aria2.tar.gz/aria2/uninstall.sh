#!/bin/sh

sh /koolshare/aria2/aria2_run.sh stop
rm -rf /koolshare/aria2
rm -rf /perp/aria2
rm -rf /koolshare/scripts/aria2_config.sh
rm -rf /webs/Module_aria2.asp

